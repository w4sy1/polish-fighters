@echo off
cd /d "%~dp0"
if exist "%~dp0LF2_v2.0a.exe" (
 "%~dp0openlf2.exe" --installer "%~dp0LF2_v2.0a.exe" --scripts "%~dp0scripts" --mod "%~dp0scripts\polish-fighters" --config-dir "%~dp0userdata\LF2"
) else (
 "%~dp0openlf2.exe" --scripts "%~dp0scripts" --mod "%~dp0scripts\polish-fighters" --config-dir "%~dp0userdata\LF2"
)
if errorlevel 1 pause
