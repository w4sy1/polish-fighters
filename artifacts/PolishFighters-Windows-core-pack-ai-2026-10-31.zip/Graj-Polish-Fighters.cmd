@echo off
cd /d "%~dp0"
"%~dp0LittleFighters.exe" --config-dir "%~dp0userdata\common"
if errorlevel 1 pause
